# XPERIA A FEAT. HATSUNE MIKU SYSTEMLESS SOUNDS

**Attention!** Some sounds have to be set manually through settings such as your default alarm sound, default notifications sound, and Phone ringtone!

Some alarm sounds/ringtones may appear repeated in the ringtone chooser, I think it depends on your rom.

Changelog 

27/01/20
-Initial Release